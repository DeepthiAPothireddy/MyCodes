﻿using Assignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment.Controllers
{
    public class messageController : Controller
    {
        public ActionResult add()
        {
            Session["visited"] = "2";
            Session["trace"] += Session["visited"].ToString();
            string trace = Session["trace"].ToString();
            if (trace.Length >= 4 && Session["pattern"]!=null)
            {
                if (trace.Substring(trace.Length - 4) == Session["pattern"].ToString())
                {
                    Session["mode"] = "secret";
                }
            }
            return View();
        }
        public ActionResult list()
        {
            Session["visited"] = "3";
            Session["trace"] += Session["visited"].ToString();
            string trace = Session["trace"].ToString();
            if (trace.Length >= 4 && Session["pattern"] != null)
            {
                if (trace.Substring(trace.Length - 4) == Session["pattern"].ToString())
                {
                    Session["mode"] = "secret";
                }
            }
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult add(add model)
        {
            if (ModelState.IsValid)
            {
                if (Session["UserName"] != null)
                {
                    if (Session["mode"] == null)
                    {
                        Session["mode"] = "nsecret";
                    }
                        string mode = Session["mode"].ToString();
                        model.Insert(mode);
                    
                }
                else
                {
                    ModelState.AddModelError("", "not logged in.");
                }
            }
            else
            {
                ModelState.AddModelError("", "title or body required.");
            }

            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult list(list model)
        {
            if (ModelState.IsValid)
            {
                if (Session["UserName"] != null)
                {
                    if (Session["mode"] == null)
                    {
                        Session["mode"] = "nsecret";
                    }
                    string mode = Session["mode"].ToString();
                    ViewBag.body = model.getlist(mode);
                }
                else
                {
                    ModelState.AddModelError("", "not logged in.");
                }
            }
            return View(model);
        }
    }
}
        
    
