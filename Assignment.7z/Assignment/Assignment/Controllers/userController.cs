﻿using Assignment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace Assignment.Controllers
{
    public class userController : Controller
    {
        public ViewResult login()
        {
            string visited = "1";
            Session["trace"] += visited;
            string trace = Session["trace"].ToString();
            if (trace.Length >= 4 && Session["pattern"]!=null)
            {
                if (trace.Substring(trace.Length - 4) == Session["pattern"].ToString())
                {
                    Session["mode"] = "secret";
                }
            }
            return View();
        }
        public ViewResult register()
        {
            string visited = "0";
            Session["trace"] += visited;
            string trace = Session["trace"].ToString();
            if (trace.Length >= 4 && Session["pattern"]!=null)
            {
                if (trace.Substring(trace.Length - 4) == Session["pattern"].ToString())
                {
                    Session["mode"] = "secret";
                }
            }
            return View();
        }

        public ActionResult user()
        {
            return View();
        }
        public ActionResult index()
        {
            return View();
        }
        public ActionResult welcome()
        {
            string visited = "4";
            Session["trace"] += visited;
            return View();
        }

        public ActionResult logout()
        {
            Session.Abandon();
            return View();
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult login(Login model)
        {
            if (ModelState.IsValid)
            {
                if (model.IsUserExist(model.username, model.password))
                {
                    ViewBag.UserName = model.username;
                    FormsAuthentication.RedirectFromLoginPage(model.username, false);
                    Session["UserName"] = model.username;
                    Session["pattern"] = model.pattern;
                }
                else
                {
                    ModelState.AddModelError("", "EmailId or Password Incorrect.");
                }
            }
            return View(model);
        }

        [HttpPost, ValidateInput(false)]
        public ActionResult register(Register model)
        {
            if (ModelState.IsValid)
            {
                if (model.IsUserExist(model.username))
                {
                    ModelState.AddModelError("", "User Id Already Exist");
                }
                else
                {
                model.pattern = model.Calculatehex(model.username);

                if (model.Insert())
                {               
                    return RedirectToAction("login", "user");
                }
                }
            }
            return View(model);
        }
    }
}