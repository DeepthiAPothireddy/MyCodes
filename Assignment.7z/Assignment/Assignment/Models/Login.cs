﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Assignment.Models
{
    public class Login
    {
        [Required(ErrorMessage = "User Name Required")]
        [DisplayName("User Name")]
        [StringLength(10, ErrorMessage = "Less than 10 characters")]
        public string username
        {
            get;
            set;
        }

        [DataType(DataType.Password)]
        [Required(ErrorMessage = "Password Required")]
        [DisplayName("Password")]
        [StringLength(30, ErrorMessage = ":Less than 30 characters")]
        public string password
        {
            get;
            set;
        }
        public string pattern
        {
            get;
            set;
        }
        public bool IsUserExist(string UserName, string password)
        {
            bool flag = false;
            MySqlConnection connection = new MySqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;
            connection.Open();
            MySqlCommand command = new MySqlCommand("select count(*) from users where username=@UserName and password=@password", connection);
            command.Parameters.AddWithValue("@UserName", UserName);
            command.Parameters.AddWithValue("@password", password);
            flag = Convert.ToBoolean(command.ExecuteScalar());
            connection.Close();
            connection.Open();
            MySqlCommand cmd = new MySqlCommand("select pattern from users where username=@user and password=@pass", connection);
            cmd.Parameters.AddWithValue("@user", UserName);
            cmd.Parameters.AddWithValue("@pass", password);
           // flag = Convert.ToBoolean(command.ExecuteScalar());
            MySqlDataReader rd = cmd.ExecuteReader();   
            while (rd.Read())
            {
                pattern = rd[0].ToString();
            }
            connection.Close();
            return flag;
        }
    }

}