﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Web;

namespace Assignment.Models
{
        public class Register
        {
            private static char[] hexadecimal = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

            [Required(ErrorMessage = "UserName Required:")]
            [DisplayName("username:")]
            [StringLength(10, ErrorMessage = "Less than 10 characters")]
            public string username { get; set; }

            [Required(ErrorMessage = "Password Required:")]
            [DataType(DataType.Password)]
            [DisplayName("password:")]
            [StringLength(30, ErrorMessage = "Less than 30 characters")]
            public string password { get; set; }

            [Required(ErrorMessage = "Confirm Password Required:")]
            [DataType(DataType.Password)]
            [Compare("password", ErrorMessage = "Confirm not matched.")]
            [Display(Name = "Confirm password:")]
            [StringLength(30, ErrorMessage = "Less than 30 characters")]
            public string password_confirm { get; set; }

            public string pattern { get; set; }


            public bool IsUserExist(string UserName)
            {
                bool flag = false;
                MySqlConnection connection = new MySqlConnection();
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;
                connection.Open();
                MySqlCommand command = new MySqlCommand("select count(*) from users where username=@UserName", connection);
                command.Parameters.AddWithValue("@UserName", UserName);
                flag = Convert.ToBoolean(command.ExecuteScalar());
                connection.Close();
                return flag;
            }

            public bool Insert()
            {
                bool flag = false;
                if (!IsUserExist(username))
                {
                    MySqlConnection connection = new MySqlConnection();
                    connection.ConnectionString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;
                    connection.Open();
                    MySqlCommand command = new MySqlCommand("insert into users values(@username,@password,@pattern)",connection);
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);
                    command.Parameters.AddWithValue("@pattern", pattern);
                    flag = Convert.ToBoolean(command.ExecuteNonQuery());
                    connection.Close();
                    return flag;
                }
                return flag;
            }
            public string Calculatehex(string input)
            {
                string hexvalue = null;
                string pattern = null;
                // step 1, calculate MD5 hash from input
                MD5 md5 = System.Security.Cryptography.MD5.Create();
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hash = md5.ComputeHash(inputBytes);

                // step 2, convert byte array to hex string
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hash.Length; i++)
                {
                    sb.Append(hash[i].ToString("X2"));
                }
                string md5string = sb.ToString();
                string lower = md5string.ToLower();
                char[] md5char = lower.ToCharArray();

                foreach (char letter in md5char)
                {
                    int  sequence = 0;
                    if (letter == '0')
                    {
                        sequence = 0 % 4;
                    }
                    if (letter == '1')
                    {
                        sequence = 1 % 4;
                    }
                    if (letter == '2')
                    {
                        sequence = 2 % 4;

                    }
                    if (letter == '3')
                    {
                        sequence = 3 % 4;
                    }
                    if (letter == '4')
                    {
                        sequence = 4 % 4;
                    }
                    if (letter == '5')
                    {
                        sequence = 5 % 4;
                    }
                    if (letter == '6')
                    {
                        sequence = 6 % 4;
                    }
                    if (letter == '7')
                    {
                        sequence = 7 % 4;
                    }
                    if (letter == '8')
                    {
                        sequence = 8 % 4;
                    }
                    if (letter == '9')
                    {
                        sequence = 9 % 4;
                    }
                    if (letter == 'a')
                    {
                        sequence = 10 % 4;
                    }
                    if (letter == 'b')
                    {
                        sequence = 11 % 4;
                    }
                    if (letter == 'c')
                    {
                        sequence = 12 % 4;
                    }
                    if (letter == 'd')
                    {
                        sequence = 13 % 4;
                    }
                    if (letter == 'e')
                    {
                        sequence = 14 % 4;
                    }
                    if (letter == 'f')
                    {
                        sequence = 15 % 4;
                    }
                    pattern += sequence;
                    /*// Get the integral value of the character.
                    int value = Convert.ToInt32(letter);
                    // Convert the decimal value to a hexadecimal value in string form.
                    string hexOutput = String.Format("{0:X}", value);
                    hexvalue += hexOutput;
                    string hexOutput = sequence.ToString();
                    hexvalue += hexOutput;
                }
                string pattern1 = hexvalue.Substring(0, 4);
                char[] patternchar = pattern1.ToCharArray();
                foreach (char letter in patternchar)
                {
                    int mod = letter % 4;
                    pattern += mod;*/
                }
                return pattern.Substring(0,4);
            }

        }
    }

