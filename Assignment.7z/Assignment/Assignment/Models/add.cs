﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Assignment.Models
{
    public class add
    {
        [Required(ErrorMessage = "title Required")]
        public string title { get; set; }
        [Required(ErrorMessage = "body Required")]
        public string message { get; set; }
        public string mode { get; set; }
        public bool Insert(string mode)
        {
                bool flag = false;
                MySqlConnection connection = new MySqlConnection();
                connection.ConnectionString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;
                connection.Open();
                MySqlCommand command = new MySqlCommand("insert into message(title,body,smode) values('" + title + "','" + message + "','" + mode + "')", connection);
                flag = Convert.ToBoolean(command.ExecuteNonQuery());
                connection.Close();
                return flag;
        }

    }
}