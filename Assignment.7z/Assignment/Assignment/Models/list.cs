﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Assignment.Models
{
    public class list
    {
        public string title { get; set; }
        public string body { get; set; }
        public string mode { get; set; }
        public string getlist(string mode)
        {
            bool flag = false;
            MySqlConnection connection = new MySqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["MySQLConnection"].ConnectionString;
            connection.Open();
            if (mode == "nsecret")
            {
                MySqlCommand command = new MySqlCommand("select * from message where smode='" + mode + "'", connection);
                MySqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    body += "title is " + rd[0].ToString() + "message is " + rd[1].ToString()+"\n";
                }
                connection.Close();
            }
            else
            {
                MySqlCommand command = new MySqlCommand("select * from message", connection);
                MySqlDataReader rd = command.ExecuteReader();
                while (rd.Read())
                {
                    body += "title : " + rd[1].ToString() + " message : " + rd[2].ToString()+"\n";
                }
                connection.Close();

            }
            return body;
        }
    }
}